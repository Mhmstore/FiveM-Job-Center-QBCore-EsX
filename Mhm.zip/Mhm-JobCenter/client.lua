local QBCore = exports['qb-core']:GetCoreObject()
local isUIOpen = false
local spawnedPeds = {}

-- 🔧 دالة إنشاء NPC بسيطة
local function CreateJobNPC(data, index)
    print("[MHM-CLIENT] Creating NPC #" .. index)
    
    local coords = data.vector4
    local x, y, z, heading = coords.x, coords.y, coords.z, coords.w
    
    Citizen.CreateThread(function()
        local model = GetHashKey(data.ped)
        
        RequestModel(model)
        while not HasModelLoaded(model) do
            Wait(100)
        end
        
        local ped = CreatePed(4, model, x, y, z - 1.0, heading, false, true)
        
        if DoesEntityExist(ped) then
            spawnedPeds[index] = ped
            
            SetEntityHeading(ped, heading)
            FreezeEntityPosition(ped, true)
            SetEntityInvincible(ped, true)
            SetBlockingOfNonTemporaryEvents(ped, true)
            SetPedDiesWhenInjured(ped, false)
            SetEntityCanBeDamaged(ped, false)
            
            RequestAnimDict("mini@strip_club@idles@bouncer@base")
            while not HasAnimDictLoaded("mini@strip_club@idles@bouncer@base") do
                Wait(100)
            end
            TaskPlayAnim(ped, "mini@strip_club@idles@bouncer@base", "base", 8.0, 0.0, -1, 1, 0, 0, 0, 0)
            
            SetModelAsNoLongerNeeded(model)
            print("[MHM-CLIENT] NPC #" .. index .. " created successfully!")
        else
            print("[MHM-CLIENT] Failed to create NPC #" .. index)
        end
    end)
end

-- دالة فتح/إغلاق الواجهة
local function ToggleUI(state)
    if state then
        isUIOpen = true
        TriggerServerEvent('jobcenter:getPlayerData')
        SetNuiFocus(true, true)
    else
        isUIOpen = false
        SetNuiFocus(false, false)
        SendNUIMessage({
            action = 'close'
        })
    end
end

-- فتح مركز الوظائف
RegisterNetEvent('jobcenter:open', function()
    ToggleUI(true)
end)

-- تحديث بيانات اللاعب
RegisterNetEvent('jobcenter:updatePlayerData', function(data)
    if isUIOpen then
        SendNUIMessage({
            action = 'updateLevel',
            playerData = data
        })
    end
end)

-- إرسال بيانات الواجهة
RegisterNetEvent('jobcenter:sendUIData', function(playerData)
    SendNUIMessage({
        action = 'open',
        jobs = Config.Jobs,
        locales = UI.Locales[UI.UiLanguage],
        playerData = playerData
    })
end)

-- NUI Callbacks
RegisterNUICallback('TakeJob', function(data, cb)
    TriggerServerEvent('jobcenter:takeJob', data)
    cb('ok')
end)

RegisterNUICallback('SetWaypoint', function(data, cb)
    SetNewWaypoint(data.x, data.y)
    QBCore.Functions.Notify(UI.Locales[UI.UiLanguage]["MarkLocateNotify"], "success", 5000)
    ToggleUI(false)
    cb('ok')
end)

RegisterNUICallback('CloseUI', function(data, cb)
    ToggleUI(false)
    cb('ok')
end)

-- 🏗️ إنشاء NPCs والأهداف
CreateThread(function()
    Wait(2000)
    
    for k, v in pairs(Config.targets) do
        if v.vector4 then
            CreateJobNPC(v, k)
            Wait(1000)
            
            local coords = v.vector4
            
            -- إنشاء Blip
            if v.blip then
                local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
                SetBlipSprite(blip, v.blip.sprite or 419)
                SetBlipDisplay(blip, 4)
                SetBlipScale(blip, v.blip.scale or 0.9)
                SetBlipColour(blip, v.blip.color or 4)
                SetBlipAsShortRange(blip, true)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentString(v.blip.label or "Job Center")
                EndTextCommandSetBlipName(blip)
            end
            
            -- إنشاء Target Zone
            exports[Exports.Target]:AddBoxZone("jobcenter_" .. k, vector3(coords.x, coords.y, coords.z), v.info1 or 1.5, v.info2 or 1.5, {
                name = "jobcenter_" .. k,
                heading = coords.w or 0,
                debugPoly = false,
                minZ = v.minZ or (coords.z - 1),
                maxZ = v.maxZ or (coords.z + 2),
            }, {
                options = {
                    {
                        type = "Client",
                        event = "jobcenter:open",
                        icon = "fas fa-briefcase",
                        label = v.TargetLabel or "مركز الوظائف",
                    },
                },
                distance = 2.5
            })
        end
    end
    
    print("[MHM-CLIENT] All NPCs and targets created!")
end)

-- إغلاق بالإسكيب
CreateThread(function()
    while true do
        Wait(0)
        if isUIOpen then
            if IsControlJustPressed(0, 322) then
                ToggleUI(false)
            end
        else
            Wait(500)
        end
    end
end)

print("^2[MHM-CLIENT] Job Center Client loaded successfully!^0")