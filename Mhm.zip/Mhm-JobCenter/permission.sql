-- جدول صلاحيات الإدارة الخاص بمركز الوظائف
CREATE TABLE `MhmJC_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `license` varchar(100) NOT NULL COMMENT 'لايسنس اللاعب',
  `citizenid` varchar(50) DEFAULT NULL COMMENT 'معرف اللاعب (اختياري)',
  `permission_level` enum('owner','admin','moderator','helper') NOT NULL DEFAULT 'helper' COMMENT 'مستوى الصلاحية',
  `can_setlevel` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'صلاحية تغيير المستويات',
  `can_addxp` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'صلاحية إضافة XP',
  `can_checklevel` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'صلاحية فحص المستويات',
  `can_manage_permissions` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'صلاحية إدارة الصلاحيات',
  `can_view_logs` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'صلاحية عرض السجلات',
  `max_xp_per_action` int(11) NOT NULL DEFAULT 1000 COMMENT 'أقصى XP يمكن إضافته في المرة الواحدة',
  `max_level_set` int(11) NOT NULL DEFAULT 50 COMMENT 'أقصى مستوى يمكن تعيينه',
  `added_by` varchar(100) DEFAULT NULL COMMENT 'من أضاف هذه الصلاحية',
  `notes` text DEFAULT NULL COMMENT 'ملاحظات إضافية',
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'حالة الصلاحية (مفعلة/معطلة)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'تاريخ الإضافة',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'تاريخ التحديث',
  `last_used` timestamp NULL DEFAULT NULL COMMENT 'آخر استخدام للصلاحية',
  PRIMARY KEY (`id`),
  UNIQUE KEY `license` (`license`),
  KEY `permission_level` (`permission_level`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='جدول صلاحيات إدارة مركز الوظائف';

-- جدول سجل العمليات الإدارية
CREATE TABLE `MhmJC_admin_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_license` varchar(100) NOT NULL COMMENT 'لايسنس الإداري',
  `admin_name` varchar(100) DEFAULT NULL COMMENT 'اسم الإداري',
  `target_license` varchar(100) DEFAULT NULL COMMENT 'لايسنس اللاعب المستهدف',
  `target_citizenid` varchar(50) DEFAULT NULL COMMENT 'معرف اللاعب المستهدف',
  `target_name` varchar(100) DEFAULT NULL COMMENT 'اسم اللاعب المستهدف',
  `action_type` enum('setlevel','addxp','checklevel','add_permission','remove_permission','edit_permission') NOT NULL COMMENT 'نوع العملية',
  `old_value` varchar(100) DEFAULT NULL COMMENT 'القيمة القديمة',
  `new_value` varchar(100) DEFAULT NULL COMMENT 'القيمة الجديدة',
  `details` text DEFAULT NULL COMMENT 'تفاصيل العملية',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'عنوان IP',
  `server_id` int(11) DEFAULT NULL COMMENT 'معرف السيرفر',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'تاريخ العملية',
  PRIMARY KEY (`id`),
  KEY `admin_license` (`admin_license`),
  KEY `target_license` (`target_license`),
  KEY `action_type` (`action_type`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='سجل العمليات الإدارية لمركز الوظائف';

-- إدراج صلاحيات المالك الافتراضية (غير اللايسنس حسب لايسنسك)
INSERT INTO `MhmJC_permissions` (
  `license`, 
  `permission_level`, 
  `can_setlevel`, 
  `can_addxp`, 
  `can_checklevel`, 
  `can_manage_permissions`, 
  `can_view_logs`, 
  `max_xp_per_action`, 
  `max_level_set`, 
  `notes`
) VALUES (
  'license:1234567890abcdef',  -- ضع لايسنسك هنا
  'owner', 
  1, 
  1, 
  1, 
  1, 
  1, 
  99999, 
  100, 
  'المالك الافتراضي - صلاحيات كاملة'
);