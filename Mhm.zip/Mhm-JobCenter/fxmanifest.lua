fx_version 'cerulean'
game 'gta5'
author 'MHM Store'
description 'Simple Job Center'
version '1.0.5'
lua54 'yes'

client_script 'client.lua'
server_script {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'   
}
shared_script 'config.lua'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

dependencies {
    'oxmysql',
    'qb-core'
}