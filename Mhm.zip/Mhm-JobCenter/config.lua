Config = {}

-- 📦 أسماء الموارد المطلوبة (لا تغير إلا إذا كان لديك أسماء مختلفة)
Exports = {
    core = "qb-core",      -- اسم مورد QBCore في سيرفرك
    Target = "qb-target"   -- اسم مورد التارجت في سيرفرك (qb-target أو ox_target)
}

-- 🗄️ إعدادات قاعدة البيانات (اختر النوع المناسب لسيرفرك)
Config.Database = {
    type = "oxmysql",      -- نوع قاعدة البيانات: "oxmysql" أو "mysql-async" أو "ghmattimysql"
    tableName = "player_levels"  -- اسم الجدول في قاعدة البيانات (يمكنك تغييره)
}

Config.LevelSystem = {
    enabled = true,            -- خله مفعل
    maxLevel = 1000,            -- أقصى مستوى يمكن الوصول إليه
    baseXP = 1000,             -- نقاط الخبرة المطلوبة للمستوى الأول
    xpMultiplier = 1.2,        -- مضاعف نقاط الخبرة لكل مستوى (كلما زاد كلما صعب الترقية)
    
    -- 📈 إعدادات اكتساب الخبرة التلقائية
    autoXP = {
        enabled = true,        -- تفعيل اكتساب XP تلقائياً كل فترة (true = مفعل، false = معطل)
        amount = 5,            -- كمية XP التي يحصل عليها اللاعب تلقائياً
        interval = 100000      -- الفترة الزمنية بالميلي ثانية (300000 = 5 دقائق)
    },
    
    -- 🎮 إعدادات عرض المستوى في UI
    showInUI = true,           -- عرض معلومات المستوى في واجهة مركز الوظائف
    showProgressBar = true,    -- عرض شريط التقدم في الواجهة
    showRequiredLevel = true   -- عرض المستوى المطلوب للوظائف المقفلة
}

-- ==========================================
-- 🎁 نظام الجوائز (يمكن تفعيله أو إلغاؤه)
-- ==========================================

Config.RewardSystem = {
    enabled = true,            -- تفعيل نظام الجوائز (true = مفعل، false = معطل)
    
    -- 🏆 جوائز المستويات (يتم منحها عند الوصول لمستوى معين)
    levelRewards = {
        [5] = {                -- عند الوصول للمستوى 5
            money = 10000,     -- مبلغ نقدي يُضاف للاعب
            type = "cash",     -- نوع المال: "cash" أو "bank"
            message = "مكافأة المستوى 5: $10,000 نقداً!"
        },
        [10] = {               -- عند الوصول للمستوى 10
            money = 25000,     
            items = {          -- عناصر يحصل عليها اللاعب
                {name = "phone", amount = 1, label = "هاتف ذكي"},
                {name = "water", amount = 5, label = "مياه"}
            },
            type = "bank",
            message = "مكافأة المستوى 10: $25,000 + هاتف ذكي!"
        },
        [15] = {               -- عند الوصول للمستوى 15
            money = 50000,
            items = {
                {name = "laptop", amount = 1, label = "لابتوب"},
                {name = "sandwich", amount = 10, label = "ساندويش"}
            },
            type = "bank",
            message = "مكافأة المستوى 15: $50,000 + لابتوب!"
        },
        [25] = {               -- عند الوصول للمستوى 25
            money = 100000,
            items = {
                {name = "advanced_lockpick", amount = 5, label = "مفاتيح متقدمة"}
            },
            type = "bank",
            message = "مكافأة المستوى 25: $100,000 + أدوات متقدمة!"
        }
    },
    
    -- 📢 إعدادات إشعارات الجوائز
    notifications = {
        showToPlayer = true,    -- إرسال إشعار للاعب عند الحصول على جائزة
        showToAll = false,      -- إرسال إشعار لجميع اللاعبين (false = للاعب فقط)
        duration = 8000         -- مدة عرض الإشعار بالميلي ثانية
    }
}

-- ==========================================
-- 🛡️ صلاحيات الإدارة (تحديد من يمكنه استخدام أوامر الإدارة)
-- ==========================================

Config.AdminPermissions = {
    -- 📋 طريقة التحقق من الصلاحيات: "license" أو "group" أو "both"
    method = "both",        -- "license" = حسب اللايسنس، "group" = حسب المجموعة، "both" = كلاهما
    
    -- 🆔 قائمة اللايسنسات المسموحة (ضع لايسنس الأشخاص المصرح لهم)
    allowedLicenses = {
        "license:aaaaaaaaaaaaaaaa",  -- ضع لايسنس المالك هنا
        "license:abcdef1234567890",  -- ضع لايسنس الادمن هنا
        "license:1111222233334444",  -- ضع لايسنس المطور هنا
        -- يمكنك إضافة المزيد حسب الحاجة
    },
    
    -- 👥 قائمة المجموعات المسموحة (في حالة استخدام طريقة "group" أو "both")
    allowedGroups = {
        "god",          -- رب السيرفر
        "admin",        -- الإدارة العامة
        "superadmin",   -- الإدارة العليا
        "moderator",    -- المشرفين
        "owner"         -- المالك
    },
    
    -- 📝 تسجيل أوامر الإدارة في الكونسول (للمراقبة والأمان)
    logCommands = true,         -- تسجيل استخدام أوامر الإدارة في الكونسول
    logToFile = false,          -- حفظ السجلات في ملف (يحتاج إعداد إضافي)
    
    -- ⚠️ إشعارات الأمان
    notifyOnInvalidUse = true   -- إرسال إشعار عند محاولة شخص غير مصرح له استخدام الأوامر
}

-- ==========================================
-- 🌐 إعدادات اللغة والواجهة
-- ==========================================

UI = {
    UiLanguage = "ar",          -- لغة الواجهة: "ar" للعربية، "en" للإنجليزية
    
    -- 📝 النصوص والترجمات
    Locales = {
        ["en"] = {              -- النصوص الإنجليزية
            ["TitleOfBackground"] = "Job Center",
            ["TitleOfBioJob"] = "Job Details:",
            ["TakeTheJob"] = "Take Job",
            ["GpsTheJob"] = "Mark Location",
            ["TakeJobNotify"] = "You were hired by",
            ["MarkLocateNotify"] = "The location is marked on the map",
            ["GeneralLevel"] = "General Level:",
            ["RequiredLevel"] = "Required Level: %s",
            ["LevelUp"] = "Level Up!",
            ["AlreadyHave"] = "You already have this job!",
            ["JobTaken"] = "Job taken successfully!",
            ["RewardReceived"] = "Level reward received!"
        },
        ["ar"] = {              -- النصوص العربية
            ["TitleOfBackground"] = "مركز الوظائف العامة",
            ["TitleOfBioJob"] = "تفاصيل الوظيفة:",
            ["TakeTheJob"] = "اخذ الوظيفة", 
            ["GpsTheJob"] = "تحديد الموقع",
            ["TakeJobNotify"] = "تم توظيفك في",
            ["MarkLocateNotify"] = "تم تحديد الموقع في الخريطة",
            ["GeneralLevel"] = "المستوى العام:",
            ["RequiredLevel"] = "يتطلب مستوى: %s",
            ["LevelUp"] = "ترقية مستوى!",
            ["AlreadyHave"] = "لديك الوظيفة بالفعل!",
            ["JobTaken"] = "تم اخذ الوظيفة",
            ["RewardReceived"] = "تم استلام مكافأة المستوى!"
        }
    }
}

-- ==========================================
-- 📍 مواقع مراكز الوظائف (NPCs والأهداف)
-- ==========================================

-- تأكد من أن الإحداثيات في الكونفق صحيحة:
Config.targets = {
    [1] = {
        vector4 = vector4(-535.4639, -212.3847, 37.64979, 30.0), -- x, y, z, heading
        info1 = 1.2,
        info2 = 1.2,
        minZ = 36.649791717529,
        maxZ = 39.049791717529,
        TargetLabel = "Mhm Job Center",
        ped = "s_m_m_highsec_01", -- بيد مدير بماسك كليب بورد
        blip = {
            sprite = 457,
            color = 4,
            scale = 0.9,
            label = "MHM Job Center"
        },
    },
    
    -- يمكنك إضافة مراكز وظائف أخرى هنا
    -- [2] = {
    --     vector4 = vector4(x, y, z, heading),
    --     info1 = 1.5,
    --     info2 = 1.5,
    --     minZ = z - 1,
    --     maxZ = z + 1,
    --     TargetLabel = "مركز وظائف إضافي",
    --     ped = "s_m_m_highsec_01",
    --     blip = {
    --         sprite = 419,
    --         color = 2,
    --         scale = 0.8,
    --         label = "Job Center 2"
    --     },
    -- },
}

-- ==========================================
-- 💼 قائمة الوظائف المتاحة
-- ==========================================

Config.Jobs = {
    -- 🚗 وظائف النقل والمواصلات
    [1] = {
        JobLabelText = "شركة المواصلات العامة",
        JobLabelIcon = "fa-solid fa-car",
        JobImageLink = "https://cdn.discordapp.com/attachments/1402512163758674032/1403793943908323349/image.png?ex=6899813d&is=68982fbd&hm=e23aeff77e9f06ca5b398676ed6a2d4d9ece7c22ceb94ecd4f7a5971496050c5&",
        JobBioText = "شركة المواصلات العامة توفر خدمات نقل الركاب عبر المدينة بأمان وراحة. تشمل المهام: نقل الركاب، صيانة المركبات، والالتزام بمواعيد الرحلات المحددة.",
        Job = "taxi",
        JobGrade = 0,
        JobCoords = vector3(895.48, -179.12, 74.7),
        xpReward = 50,
        requiredLevel = 1
    },
    
    [2] = {
        JobLabelText = "شركة النقل البري",
        JobLabelIcon = "fa-solid fa-truck",
        JobImageLink = "https://forum-cfx-re.akamaized.net/optimized/5X/6/a/0/1/6a017bb0249b66de3f489c8a58658baf14e24bfc_2_690x318.jpeg",
        JobBioText = "شركة متخصصة في نقل البضائع والمعدات الثقيلة عبر الطرق السريعة. تتطلب رخصة قيادة المركبات الثقيلة والقدرة على السفر لمسافات طويلة.",
        Job = "trucker",
        JobGrade = 0,
        JobCoords = vector3(1240.35, -2892.51, 5.9),
        xpReward = 75,
        requiredLevel = 3
    },

    -- 🗑️ وظائف النظافة والبيئة
    [3] = {
        JobLabelText = "شركة إدارة النظافة",
        JobLabelIcon = "fa-solid fa-recycle",
        JobImageLink = "https://i.ytimg.com/vi/HCJbWP8Cn68/maxresdefault.jpg",
        JobBioText = "شركة متخصصة في إدارة النفايات وخدمات النظافة العامة. المهام تشمل: جمع القمامة، تنظيف الشوارع، والمحافظة على نظافة البيئة.",
        Job = "garbage",
        JobGrade = 0,
        JobCoords = vector3(-322.46, -1545.76, 31.02),
        xpReward = 60,
        requiredLevel = 2
    },

    -- ⚡ وظائف المرافق العامة
    [4] = {
        JobLabelText = "شركة الكهرباء",
        JobLabelIcon = "fa-solid fa-bolt",
        JobImageLink = "https://forum-cfx-re.akamaized.net/optimized/5X/5/8/6/3/586393f77a6c9da4811caeea24ecd0006f5f9cd2_2_517x291.jpeg",
        JobBioText = "شركة مسؤولة عن صيانة شبكات الكهرباء في المدينة. تتطلب معرفة تقنية بالأنظمة الكهربائية، وتشمل إصلاح الأعطال الطارئة.",
        Job = "electrician",
        JobGrade = 0,
        JobCoords = vector3(486.35, -1312.23, 29.23),
        xpReward = 100,
        requiredLevel = 12
    },

    -- ♻️ وظائف إعادة التدوير
    [5] = {
        JobLabelText = "شركة إعادة التدوير",
        JobLabelIcon = "fa-solid fa-leaf",
        JobImageLink = "https://forum-cfx-re.akamaized.net/original/4X/4/2/a/42aafd78623f8f4d5ae47a6796a38e06eae861e6.jpeg",
        JobBioText = "شركة بيئية متخصصة في إعادة تدوير المواد والمحافظة على البيئة. تشمل المهام: فرز المواد القابلة للتدوير، معالجة النفايات، وتطوير برامج الاستدامة.",
        Job = "recycling",
        JobGrade = 0,
        JobCoords = vector3(-359.24, -1569.83, 25.23),
        xpReward = 80,
        requiredLevel = 5
    },

    -- 🐔 وظائف الإنتاج الزراعي
    [6] = {
        JobLabelText = "شركة الدواجن",
        JobLabelIcon = "fa-solid fa-drumstick-bite",
        JobImageLink = "https://img.gta5-mods.com/q95/images/driverjobs-v/3f4ec8-3.jpg",
        JobBioText = "شركة متخصصة في تربية الدواجن وإنتاج البيض واللحوم عالية الجودة. تتطلب معرفة بأساسيات تربية الحيوانات والاهتمام بالصحة البيطرية.",
        Job = "poultry",
        JobGrade = 0,
        JobCoords = vector3(2469.34, 4462.81, 35.81),
        xpReward = 70,
        requiredLevel = 4
    },

    -- 🐟 وظائف الصيد البحري
    [7] = {
        JobLabelText = "شركة الأسماك",
        JobLabelIcon = "fa-solid fa-fish",
        JobImageLink = "https://cdn.discordapp.com/attachments/1402512163758674032/1404017366781657108/image.png?ex=6899a891&is=68985711&hm=e1fda27526760e87293dc31131ff46185736930e0934c3b6e49b4bd9f8ab32b6&",
        JobBioText = "شركة متخصصة في صيد الأسماك وتوريد المأكولات البحرية الطازجة. تشمل المهام: الصيد في أعماق البحار، معالجة الأسماك، وضمان جودة المنتجات البحرية.",
        Job = "fishing",
        JobGrade = 0,
        JobCoords = vector3(-1816.93, -1193.65, 14.31),
        xpReward = 65,
        requiredLevel = 3
    },

    -- 🎯 وظائف الصيد البري
    [8] = {
        JobLabelText = "شركة الصيد",
        JobLabelIcon = "fa-solid fa-crosshairs",
        JobImageLink = "https://www.gtabase.com/images/gta-5/missions/side-missions/hunting.jpg",
        JobBioText = "شركة متخصصة في الصيد البري وتوريد اللحوم الطبيعية عالية الجودة. تتطلب رخصة صيد ومعرفة بقوانين الصيد المحلية وتقنيات الصيد الآمنة.",
        Job = "hunting",
        JobGrade = 0,
        JobCoords = vector3(-679.14, 5834.52, 17.33),
        xpReward = 90,
        requiredLevel = 15
    },

    -- 😈 وظائف خاصة ومتقدمة
    [9] = {
        JobLabelText = "شركة الاختطاف",
        JobLabelIcon = "fa-solid fa-user-secret",
        JobImageLink = "https://img.gta5-mods.com/q95/images/saf-special-operations-task-force-franksteer/9787a6-army4.jpg",
        JobBioText = "عمل غير قانوني يتطلب مستوى عالٍ من الخبرة والسرية. مخصص للأشخاص ذوي الخبرة العالية في العمليات الخاصة والتعامل مع المواقف الصعبة.",
        Job = "kidnapper",
        JobGrade = 0,
        JobCoords = vector3(707.84, -966.89, 30.41),
        xpReward = 200,
        requiredLevel = 10
    },

    -- 🏭 وظائف الصناعة والتصنيع
    [10] = {
        JobLabelText = "شركة التصنيع والإنتاج",
        JobLabelIcon = "fa-solid fa-industry",
        JobImageLink = "https://images.squarespace-cdn.com/content/v1/626cbf630ab65c7c091228a2/af18fb48-e6fe-4193-ae74-970240b201ce/virtual-reality-career-learning-manufacturing-01.jpg",
        JobBioText = "شركة صناعية متخصصة في تصنيع المواد والمنتجات المختلفة. تشمل المهام: تشغيل المعدات الصناعية، مراقبة جودة الإنتاج، وصيانة خطوط الإنتاج.",
        Job = "manufacturing",
        JobGrade = 0,
        JobCoords = vector3(716.84, -962.05, 30.39),
        xpReward = 110,
        requiredLevel = 8
    }
}

-- ==========================================
-- 🔧 إعدادات متقدمة (للمطورين)
-- ==========================================

Config.Advanced = {
    -- 🔄 إعدادات التحديث والتزامن
    updateInterval = 5000,      -- فترة تحديث البيانات بالميلي ثانية
    saveInterval = 30000,       -- فترة حفظ البيانات تلقائياً
    
    -- 🎨 إعدادات الواجهة
    enableAnimations = true,    -- تفعيل الرسوم المتحركة في الواجهة
    enableSounds = true,        -- تفعيل الأصوات
    
    -- 🐛 إعدادات التشخيص والإصلاح
    debugMode = false,          -- تفعيل وضع التشخيص (true = مفعل، false = معطل)
    enableErrorReporting = true, -- تفعيل تقارير الأخطاء
    
    -- 🔐 إعدادات الأمان الإضافية
    enableRateLimit = true,     -- تفعيل حد معدل الطلبات لمنع الإساءة
    maxRequestsPerMinute = 10   -- أقصى عدد طلبات في الدقيقة للاعب الواحد
}

-- ==========================================
-- 📋 معلومات السكربت
-- ==========================================

Config.ScriptInfo = {
    name = "MHM Job Center",
    version = "1.0.0",
    author = "MHM Store",
    description = "نظام مركز الوظائف المتقدم مع نظام المستويات والجوائز",
    discord = "https://discord.gg/g8RZKrhsdR",
    lastUpdate = "2025-08-10"
}