// متغيرات عامة
let currentJobs = [];
let currentLocales = {};
let playerData = {};
let selectedJobIndex = 0;

// دالة الحصول على اسم المورد
function getResourceName() {
    return window.location.hostname === '' ? GetParentResourceName() : 'mhm-jobcenter';
}

// دالة حساب XP المطلوب
function calculateRequiredXP(level) {
    return Math.floor(1000 * Math.pow(1.2, level - 1));
}

// دالة تحديث معلومات المستوى
function updatePlayerLevel() {
    const level = playerData.level || 1;
    const currentXP = playerData.xp || 0;
    const maxXP = calculateRequiredXP(level + 1);
    
    document.getElementById('player-level').textContent = `المستوى العام: ${currentXP}/${maxXP}`;
}

// دالة تحديث شريط التقدم
function updateProgressBar(job) {
    if (!job) {
        document.getElementById('progress-bar').style.display = 'none';
        return;
    }
    
    const playerLevel = playerData.level || 1;
    const requiredLevel = job.requiredLevel || 1;
    const currentXP = playerData.xp || 0;
    const maxXP = calculateRequiredXP(playerLevel + 1);
    const progress = Math.min((currentXP / maxXP) * 100, 100);
    const isAccessible = playerLevel >= requiredLevel;
    
    document.getElementById('current-xp').textContent = `${currentXP}/${maxXP}`;
    document.getElementById('progress-level').textContent = `المستوى ${requiredLevel}`;
    document.getElementById('required-level').textContent = `يتطلب مستوى: ${requiredLevel}`;
    
    const progressLevel = document.getElementById('progress-level');
    if (isAccessible) {
        progressLevel.classList.add('accessible');
    } else {
        progressLevel.classList.remove('accessible');
    }
    
    document.getElementById('progress-fill').style.width = progress + '%';
    document.getElementById('progress-bar').style.display = 'block';
}

// دالة تحميل الوظائف
function loadJobs() {
    const jobsList = document.getElementById('jobs-list');
    jobsList.innerHTML = '';
    
    currentJobs.forEach((job, index) => {
        const playerLevel = playerData.level || 1;
        const isAccessible = playerLevel >= (job.requiredLevel || 1);
        
        const jobItem = document.createElement('div');
        jobItem.className = `job-item ${!isAccessible ? 'locked' : ''}`;
        jobItem.setAttribute('data-index', index);
        
        // 🎯 إضافة المستوى المطلوب كـ attribute للوظائف المقفلة
        if (!isAccessible) {
            jobItem.setAttribute('data-required-level', `المستوى ${job.requiredLevel || 1}`);
        }
        
        jobItem.innerHTML = `
            <div class="job-icon">
                <i class="${job.JobLabelIcon}"></i>
            </div>
            <div class="job-name">${job.JobLabelText}</div>
        `;
        
        jobItem.addEventListener('click', () => selectJob(index));
        jobsList.appendChild(jobItem);
    });
    
    // اختيار الوظيفة الأولى
    if (currentJobs.length > 0) {
        selectJob(0);
    }
}

// دالة اختيار الوظيفة
function selectJob(index) {
    // إزالة التحديد من الكل
    document.querySelectorAll('.job-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // تحديد الوظيفة الجديدة
    const selectedItem = document.querySelector(`[data-index="${index}"]`);
    if (selectedItem) {
        selectedItem.classList.add('active');
    }
    
    selectedJobIndex = index;
    const job = currentJobs[index];
    
    if (job) {
        // إظهار تفاصيل الوظيفة
        document.getElementById('job-details').style.display = 'block';
        
        // تحديث التفاصيل
        document.getElementById('job-img').src = job.JobImageLink;
        document.getElementById('job-title').textContent = currentLocales["TitleOfBioJob"] || 'تفاصيل الوظيفة:';
        document.getElementById('job-description').textContent = job.JobBioText;
        
        // تحديث الأزرار
        const takeJobBtn = document.getElementById('take-job-btn');
        const playerLevel = playerData.level || 1;
        const isAccessible = playerLevel >= (job.requiredLevel || 1);
        
        if (isAccessible) {
            takeJobBtn.textContent = currentLocales["TakeTheJob"] || 'اخذ الوظيفة';
            takeJobBtn.disabled = false;
        } else {
            takeJobBtn.textContent = `مستوى ${job.requiredLevel} مطلوب`;
            takeJobBtn.disabled = true;
        }
        
        document.getElementById('gps-btn').textContent = currentLocales["GpsTheJob"] || 'تحديد الموقع';
        
        // تحديث شريط التقدم
        updateProgressBar(job);
    }
}

// دالة أخذ الوظيفة
function takeJob() {
    const job = currentJobs[selectedJobIndex];
    if (!job) return;
    
    const playerLevel = playerData.level || 1;
    const isAccessible = playerLevel >= (job.requiredLevel || 1);
    
    if (!isAccessible) {
        console.log('Job is locked');
        return;
    }
    
    // إرسال البيانات
    const data = {
        JobLua: job.Job,
        JobGradeLua: job.JobGrade,
        xpReward: job.xpReward || 100
    };
    
    console.log('Taking job:', data);
    
    fetch(`https://${getResourceName()}/TakeJob`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    }).catch(console.error);
}

// دالة تحديد الموقع
function setWaypoint() {
    const job = currentJobs[selectedJobIndex];
    if (!job) return;
    
    const coords = {
        x: job.JobCoords.x,
        y: job.JobCoords.y,
        z: job.JobCoords.z
    };
    
    console.log('Setting waypoint:', coords);
    
    fetch(`https://${getResourceName()}/SetWaypoint`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    }).catch(console.error);
}

// دالة إغلاق الواجهة
function closeUI() {
    console.log('Closing UI');
    
    fetch(`https://${getResourceName()}/CloseUI`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    }).catch(console.error);
}

// ربط الأحداث
document.addEventListener('DOMContentLoaded', function() {
    // أزرار الإجراءات
    document.getElementById('take-job-btn').addEventListener('click', takeJob);
    document.getElementById('gps-btn').addEventListener('click', setWaypoint);
    document.getElementById('close-btn').addEventListener('click', closeUI);
    
    // إغلاق بالإسكيب
    document.addEventListener('keyup', function(e) {
        if (e.key === 'Escape') {
            closeUI();
        }
    });
    
    console.log('Job Center UI initialized');
});

// استقبال الرسائل
window.addEventListener('message', function(event) {
    const data = event.data;
    
    if (data.action === 'open') {
        currentJobs = data.jobs || [];
        currentLocales = data.locales || {};
        playerData = data.playerData || {};
        
        // تحديث النصوص
        document.getElementById('title').textContent = currentLocales["TitleOfBackground"] || 'مركز الوظائف العامة';
        
        // تحديث البيانات
        updatePlayerLevel();
        loadJobs();
        
        // إظهار الواجهة
        document.getElementById('app').style.display = 'block';
        
        console.log('UI opened with', currentJobs.length, 'jobs');
        
    } else if (data.action === 'close') {
        document.getElementById('app').style.display = 'none';
        console.log('UI closed');
        
    } else if (data.action === 'updateLevel') {
        playerData = data.playerData || {};
        updatePlayerLevel();
        
        // إعادة تحميل الوظائف لتحديث القفل
        loadJobs();
        
        console.log('Level updated');
    }
});

console.log('Job Center script loaded');