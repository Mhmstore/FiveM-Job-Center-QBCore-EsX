local QBCore = exports['qb-core']:GetCoreObject()

-- Database Functions
local function GetPlayerLevelData(citizenid)
    local result = MySQL.query.await('SELECT * FROM player_levels WHERE citizenid = ?', {citizenid})
    
    if result and result[1] then
        return result[1]
    else
        MySQL.insert('INSERT INTO player_levels (citizenid, level, xp, total_xp) VALUES (?, ?, ?, ?)', {
            citizenid, 1, 0, 0
        })
        return { citizenid = citizenid, level = 1, xp = 0, total_xp = 0 }
    end
end

local function UpdatePlayerLevelData(citizenid, data)
    MySQL.update('UPDATE player_levels SET level = ?, xp = ?, total_xp = ? WHERE citizenid = ?', {
        data.level, data.xp, data.total_xp, citizenid
    })
end

local function CalculateRequiredXP(level)
    return math.floor(Config.LevelSystem.baseXP * (Config.LevelSystem.xpMultiplier ^ (level - 1)))
end

local function AddPlayerXP(citizenid, amount)
    local data = GetPlayerLevelData(citizenid)
    local originalLevel = data.level
    
    data.xp = data.xp + amount
    data.total_xp = data.total_xp + amount
    
    while data.xp >= CalculateRequiredXP(data.level) and data.level < Config.LevelSystem.maxLevel do
        data.xp = data.xp - CalculateRequiredXP(data.level)
        data.level = data.level + 1
    end
    
    UpdatePlayerLevelData(citizenid, data)
    
    return {
        levelData = data,
        levelsGained = data.level - originalLevel
    }
end

local function SetPlayerLevel(citizenid, newLevel)
    if newLevel < 1 then newLevel = 1 end
    if newLevel > Config.LevelSystem.maxLevel then newLevel = Config.LevelSystem.maxLevel end
    
    local data = GetPlayerLevelData(citizenid)
    data.level = newLevel
    data.xp = 0
    data.total_xp = CalculateRequiredXP(newLevel)
    
    UpdatePlayerLevelData(citizenid, data)
    
    return data
end

-- Events
RegisterNetEvent('jobcenter:getPlayerData', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if Player then
        local citizenid = Player.PlayerData.citizenid
        local levelData = GetPlayerLevelData(citizenid)
        TriggerClientEvent('jobcenter:sendUIData', src, levelData)
    end
end)

RegisterNetEvent('jobcenter:takeJob', function(data)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    local citizenid = Player.PlayerData.citizenid
    local currentJob = Player.PlayerData.job.name
    
    -- فحص إذا اللاعب عنده نفس الوظيفة
    if currentJob == data.JobLua then
        TriggerClientEvent('QBCore:Notify', src, UI.Locales[UI.UiLanguage]["AlreadyHave"], 'error')
        return
    end
    
    -- فحص المستوى المطلوب
    local levelData = GetPlayerLevelData(citizenid)
    local requiredLevel = 1
    
    for _, job in pairs(Config.Jobs) do
        if job.Job == data.JobLua then
            requiredLevel = job.requiredLevel or 1
            break
        end
    end
    
    if levelData.level < requiredLevel then
        TriggerClientEvent('QBCore:Notify', src, string.format(UI.Locales[UI.UiLanguage]["RequiredLevel"], requiredLevel), 'error')
        return
    end
    
    -- تغيير الوظيفة
    Player.Functions.SetJob(data.JobLua, data.JobGradeLua)
    
    -- إضافة XP
    local result = AddPlayerXP(citizenid, data.xpReward)
    
    -- إشعارات
    TriggerClientEvent('QBCore:Notify', src, UI.Locales[UI.UiLanguage]["JobTaken"], 'success')
    
    if result.levelsGained > 0 then
        TriggerClientEvent('QBCore:Notify', src, UI.Locales[UI.UiLanguage]["LevelUp"] .. " " .. result.levelData.level, 'success')
    end
    
    -- تحديث البيانات
    TriggerClientEvent('jobcenter:updatePlayerData', src, result.levelData)
end)

-- 🎯 كوماندات بسيطة للتجريب (بدون نظام صلاحيات معقد)
QBCore.Commands.Add('setlevel', 'تعديل مستوى اللاعب', {
    {name = 'id', help = 'رقم اللاعب'},
    {name = 'level', help = 'المستوى الجديد'}
}, true, function(source, args)
    local src = source
    local targetId = tonumber(args[1])
    local newLevel = tonumber(args[2])
    
    if not targetId or not newLevel then
        TriggerClientEvent('QBCore:Notify', src, 'استخدام خاطئ: /setlevel [id] [level]', 'error')
        return
    end
    
    local targetPlayer = QBCore.Functions.GetPlayer(targetId)
    if not targetPlayer then
        TriggerClientEvent('QBCore:Notify', src, 'اللاعب غير متصل!', 'error')
        return
    end
    
    if newLevel < 1 or newLevel > Config.LevelSystem.maxLevel then
        TriggerClientEvent('QBCore:Notify', src, 'المستوى يجب أن يكون بين 1 و ' .. Config.LevelSystem.maxLevel, 'error')
        return
    end
    
    local targetCitizenId = targetPlayer.PlayerData.citizenid
    local targetName = targetPlayer.PlayerData.charinfo.firstname .. ' ' .. targetPlayer.PlayerData.charinfo.lastname
    
    local newData = SetPlayerLevel(targetCitizenId, newLevel)
    
    TriggerClientEvent('QBCore:Notify', src, string.format('تم تعديل مستوى %s إلى %d', targetName, newLevel), 'success')
    TriggerClientEvent('QBCore:Notify', targetId, string.format('تم تعديل مستواك إلى %d', newLevel), 'info')
    TriggerClientEvent('jobcenter:updatePlayerData', targetId, newData)
    
end, 'admin')

QBCore.Commands.Add('addxp', 'إضافة XP للاعب', {
    {name = 'id', help = 'رقم اللاعب'},
    {name = 'amount', help = 'كمية XP'}
}, true, function(source, args)
    local src = source
    local targetId = tonumber(args[1])
    local xpAmount = tonumber(args[2])
    
    if not targetId or not xpAmount then
        TriggerClientEvent('QBCore:Notify', src, 'استخدام خاطئ: /addxp [id] [amount]', 'error')
        return
    end
    
    local targetPlayer = QBCore.Functions.GetPlayer(targetId)
    if not targetPlayer then
        TriggerClientEvent('QBCore:Notify', src, 'اللاعب غير متصل!', 'error')
        return
    end
    
    if xpAmount < 1 or xpAmount > 10000 then
        TriggerClientEvent('QBCore:Notify', src, 'كمية XP يجب أن تكون بين 1 و 10000', 'error')
        return
    end
    
    local targetCitizenId = targetPlayer.PlayerData.citizenid
    local targetName = targetPlayer.PlayerData.charinfo.firstname .. ' ' .. targetPlayer.PlayerData.charinfo.lastname
    
    local result = AddPlayerXP(targetCitizenId, xpAmount)
    
    TriggerClientEvent('QBCore:Notify', src, string.format('تم إضافة %d XP لـ %s', xpAmount, targetName), 'success')
    TriggerClientEvent('QBCore:Notify', targetId, string.format('حصلت على %d XP', xpAmount), 'success')
    
    if result.levelsGained > 0 then
        TriggerClientEvent('QBCore:Notify', targetId, string.format('ترقية مستوى! المستوى الجديد: %d', result.levelData.level), 'success')
    end
    
    TriggerClientEvent('jobcenter:updatePlayerData', targetId, result.levelData)
    
end, 'admin')

print("^2[MHM] Simple Job Center Server loaded!^0")